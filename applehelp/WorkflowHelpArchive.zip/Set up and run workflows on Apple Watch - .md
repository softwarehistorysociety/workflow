# "Set up and run workflows on Apple Watch"

*23-08-2022 22:31* 

> Run workflows on Apple Watch
Run workflows on Apple Watch

![](https://help.apple.com/workflow/en.lproj/GlobalArt/AppIconDefault_Workflow.png)

You can add workflows to Apple Watch for easy access from the Home screen, from the Dock, or from a watch face complication.

## Add the Workflow app to Apple Watch

## Add Workflow to the Dock

## Add the Workflow complication to the watch face

## Enable a workflow to appear on Apple Watch

## Run a workflow on Apple Watch

## Run a workflow from the Workflow complication

[Previous](https://help.apple.com/workflow/#/apdbe2ceb96c) [Next](https://help.apple.com/workflow/#/apd0c4253a27)

© 2018 Apple Inc. All rights reserved.
***

==**479**== Words

- **[Set up and run workflows on Apple Watch - Workflow Help](https://help.apple.com/workflow/#/apda76e13e28)**