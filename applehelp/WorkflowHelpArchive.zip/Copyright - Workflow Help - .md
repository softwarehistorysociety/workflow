# "Copyright - Workflow Help"

*23-08-2022 22:31* 

> Apple Inc.
## Copyright

Apple Inc.

© 2018 Apple Inc. All rights reserved.

Use of the “keyboard” Apple logo (Option-Shift-K) for commercial purposes without the prior written consent of Apple may constitute trademark infringement and unfair competition in violation of federal and state laws.

Apple, the Apple logo, Apple Watch, FaceTime, Handoff, iBooks, iPad, iPhone, iTunes, Mac, Pages, Safari, and Siri are trademarks of Apple Inc., registered in the U.S. and other countries.

App Store, iBooks Store, and iTunes Store are service marks of Apple Inc., registered in the U.S. and other countries.

Apple Inc.

One Apple Park Way

Cupertino, CA 95014

USA

[apple.com](https://www.apple.com/)

IOS is a trademark or registered trademark of Cisco in the U.S. and other countries and is used under license.

The Bluetooth® word mark and logos are registered trademarks owned by Bluetooth SIG, Inc. and any use of such marks by Apple Inc. is under license.

UNIX® is a registered trademark of The Open Group.

Other company and product names mentioned herein may be trademarks of their respective companies. Mention of third-party products is for informational purposes only and constitutes neither an endorsement nor a recommendation. Apple assumes no responsibility with regard to the performance or use of these products.

Every effort has been made to ensure that the information in this manual is accurate. Apple is not responsible for printing or clerical errors.

Some apps are not available in all areas. App availability is subject to change.
***

==**1488**== Words

- **[Copyright - Workflow Help](https://help.apple.com/workflow/#/apd19e3e6994)**