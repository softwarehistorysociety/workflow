# "Navigate the Actions list - Workflow Help"

*23-08-2022 22:31* 

> Work with actions
Work with actions

![](https://help.apple.com/workflow/en.lproj/GlobalArt/AppIconDefault_Workflow.png)

## Navigate the Actions list

As you [add actions to your custom workflow](https://help.apple.com/workflow/#/apd84c576f8c), you can view information about each action, sort the list of available actions by category or by search term, and create favorite actions for future use.

## View information about an action

## Filter the list of actions

## View all actions in a specific category

## View suggested actions

## Mark an action as a favorite

## View favorite actions

[Previous](https://help.apple.com/workflow/#/apd84c576f8c) [Next](https://help.apple.com/workflow/#/apde53ab0903)

© 2018 Apple Inc. All rights reserved.
***

==**511**== Words

- **[Navigate the Actions list - Workflow Help](https://help.apple.com/workflow/#/apdc33e4f4da)**