# "Open, create, and run a workflow"

*23-08-2022 22:31* 

> Use URL schemes with Workflow
Use URL schemes with Workflow

![](https://help.apple.com/workflow/en.lproj/GlobalArt/AppIconDefault_Workflow.png)

The Workflow URL scheme allows you to open the app, create, run, or import a workflow, and interact with the Gallery in the Workflow app.

## Open Workflow

## Creating a new workflow

## Open a specific workflow

[Previous](https://help.apple.com/workflow/#/apd621a1ad7a) [Next](https://help.apple.com/workflow/#/apd624386f42)

Was this help page useful? Send feedback.

© 2018 Apple Inc. All rights reserved.
***

==**381**== Words

- **[Open, create, and run a workflow - Workflow Help](https://help.apple.com/workflow/#/apda283236d7)**