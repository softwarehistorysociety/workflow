# "Organize workflows - Workflow Help"

*23-08-2022 22:31* 

> Manage workflows
Manage workflows

![](https://help.apple.com/workflow/en.lproj/GlobalArt/AppIconDefault_Workflow.png)

## Organize workflows

In addition to adding and organizing workflows in the Workflow app, you can determine which workflows appear in the Workflow widget in Today View on iPhone or iPad, and on Apple Watch. Workflows appear in the same order on iOS devices and on Apple Watch as they do in the Workflow app (in the My Workflows and Settings screens).

## Organize workflows in the My Workflows screen

## Organize workflows in the Settings screen

## Organize workflows in iOS Today View

## Organize workflows and complications on Apple Watch

[Previous](https://help.apple.com/workflow/#/apd5b1537ca0) [Next](https://help.apple.com/workflow/#/apd6b467942c)

© 2018 Apple Inc. All rights reserved.
***

==**639**== Words

- **[Organize workflows - Workflow Help](https://help.apple.com/workflow/#/apd052072d68)**